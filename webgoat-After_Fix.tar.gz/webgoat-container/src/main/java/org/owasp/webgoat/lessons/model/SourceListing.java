/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.owasp.webgoat.lessons.model;

/**
 * <p>SourceListing class.</p>
 *
 * @author rlawson
 * @version $Id: $Id
 */
public class SourceListing {
    
    private String source;

    /**
     * <p>Getter for the field <code>source</code>.</p>
     *
     * @return the source
     */
    public String getSource() {
        return source;
    }

    /**
     * <p>Setter for the field <code>source</code>.</p>
     *
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }
    
}
